package src.main.java;

public class CustomClassListener extends JobListener {
	
}
