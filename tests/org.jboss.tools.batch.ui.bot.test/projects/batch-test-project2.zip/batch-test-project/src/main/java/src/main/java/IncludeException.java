package src.main.java;

public class IncludeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
