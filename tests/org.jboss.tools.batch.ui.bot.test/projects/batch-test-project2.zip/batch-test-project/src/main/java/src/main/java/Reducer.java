package src.main.java;

import javax.batch.api.partition.AbstractPartitionReducer;
import javax.inject.Named;

@Named
public class Reducer extends AbstractPartitionReducer {

	public Reducer() {
		// TODO Auto-generated constructor stub
	}

}
