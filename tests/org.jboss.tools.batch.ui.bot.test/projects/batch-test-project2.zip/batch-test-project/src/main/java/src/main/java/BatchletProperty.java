package src.main.java;

import javax.batch.api.AbstractBatchlet;
import javax.batch.api.BatchProperty;
import javax.inject.Inject;
import javax.inject.Named;

@Named
public class BatchletProperty extends AbstractBatchlet {

	@Inject
	@BatchProperty
	protected String myPropertyRenamed;

	@Inject
	@BatchProperty
	protected String myProperty1;
	
	@Inject
	@BatchProperty
	protected String myProperty2;
	
	public BatchletProperty() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String process() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
