package src.main.java;

import java.util.List;

import javax.batch.api.chunk.AbstractItemWriter;
import javax.inject.Named;

@Named
public class Writer extends AbstractItemWriter {

	public Writer() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void writeItems(List<Object> items) throws Exception {
		// TODO Auto-generated method stub

	}

}
