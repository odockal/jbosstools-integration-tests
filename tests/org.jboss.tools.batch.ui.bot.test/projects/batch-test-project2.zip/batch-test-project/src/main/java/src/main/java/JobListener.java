package src.main.java;

import javax.batch.api.listener.AbstractJobListener;
import javax.inject.Named;

@Named
public class JobListener extends AbstractJobListener {

	public JobListener() {
		// TODO Auto-generated constructor stub
	}

}
